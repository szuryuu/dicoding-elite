import './styles/styles.css';
import './component/searchNotes.js'
import './component/dataNotes.js'
import './component/sideBar.js'

